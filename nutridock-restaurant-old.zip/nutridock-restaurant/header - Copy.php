<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<title>Nutridock</title>
<meta content="" name="description">
<meta content="" name="keywords">

<!-- Favicons -->
<link href="assets/img/favicon.png" rel="icon">
<link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
<link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
<link href="assets/vendor/aos/aos.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Prata&display=swap" rel="stylesheet">
<!-- Template Main CSS File -->
<link href="assets/css/style.css" rel="stylesheet">

<!-- =======================================================
  * Template Name: BizLand - v2.0.0
  * Template URL: https://bootstrapmade.com/bizland-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->

</head>

<body>

<!-- ======= Top Bar ======= -->
<div id="topbar" class="d-none d-lg-flex align-items-center fixed-top">
  <div class="container d-flex">
    <div class="contact-info mr-auto"> <i class="icofont-location-pin"></i> <a href="mailto:contact@example.com">contact@example.com</a> <i class="icofont-phone"></i> +1 5589 55488 55 </div>
    <div class="social-links"> 
      <!-- <a href="#" class="twitter"><i class="icofont-twitter"></i></a> --> 
      <a href="#" class="facebook"><i class="icofont-facebook"></i></a> <a href="#" class="instagram"><i class="icofont-instagram"></i></a> 
      <!-- <a href="#" class="skype"><i class="icofont-skype"></i></a> --> 
      <a href="#" class="linkedin"><i class="icofont-linkedin"></i></i></a> </div>
  </div>
</div>

<!-- ======= Header ======= -->
<header id="header" class="fixed-top">
  <div class="container d-flex align-items-center"> 
    
    <!--  <h1 class="logo mr-auto"><a href="index.php">BizLand<span>.</span></a></h1> --> 
    <!-- Uncomment below if you prefer to use an image logo --> 
    <a href="index.php" class="logo mobile-logo"> <img src="assets/img/logo.png" alt="nutridock"> </a>
    <nav class="nav-menu d-none d-lg-block mx-auto">
      <ul>
        <li class="active"><a href="index.php">Home</a></li>
        <li><a href="about-us.php">About</a></li>
        <li><a href="menu.php">Menu</a></li>
        <li><a href="blog-list.php">BLOG</a></li>
        <li><a href="faq.php">FAQ</a></li>
        <li><a href="contact-us.php">Contact</a></li>
        <li><a href="">TRACKING</a></li>

        <!-- <li><a href="#team">Team</a></li>
          <li class="drop-down"><a href="">Drop Down</a>
            <ul>
              <li><a href="#">Drop Down 1</a></li>
              <li class="drop-down"><a href="#">Deep Drop Down</a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>
              <li><a href="#">Drop Down 2</a></li>
              <li><a href="#">Drop Down 3</a></li>
              <li><a href="#">Drop Down 4</a></li>
            </ul>
         </li> -->
      </ul>
    </nav>
    <!-- .nav-menu -->
    <div class="cart-op d-lg-flex">
      <ul class="">
        <li>
          <form class="searchbox">
            <input type="search" placeholder="Search......" name="search" class="searchbox-input" onkeyup="buttonUp();" required>
            <input type="submit" class="searchbox-submit" value="GO">
            <span class="searchbox-icon"><i class="icofont-search"></i></span>
          </form>
        </li>
      <!--   <li class="position-relative">
          <button class="class-cart bg-white border-0"> <i class="icofont-cart-alt"></i> <span class="count-cart">2</span> </button>
        </li> -->
       <!--  <li>
         <div class="dropdown">
            <button class="btn class-cart dropdown-toggle p-0" data-toggle="dropdown"> <i class="icofont-cart-alt"></i> <span class="count-cart">2</span> </button>
            <div class="dropdown-menu cart-list">
              <div class="cart-inline-header">
                <h5 class="cart-inline-title">In cart:<span> 2</span> Products</h5>
                <h6 class="cart-inline-title">Total price:<span> $43</span></h6>
              </div>
              <div class="cart-inline-body">
                <div class="cart-inline-item">
                  <div class="unit unit-spacing-sm align-items-center">
                    <div class="unit-left">
                      <a class="cart-inline-figure" href="single-product.html">
                        <img src="assets/img/product-mini-6-100x90.png" alt="" width="100" height="90">
                      </a>
                     </div>
                     <div class="unit-body w-100">
                       <h6 class="cart-inline-title mb-2">
                        <a href="single-product.html" style="color: inherit;">Oranges</a>
                      </h6>
                       <div>
                         <div class="group-xs group-middle" style="width: 135px;float: left;">
                           <div class="table-cart-stepper">
                             <div class="input-group cart-item-plus">
                                <span class="input-group-btn">
                                    <button type="button" class="btn btn-number" disabled="disabled" data-type="minus" data-field="quant[1]">
                                        <i class="icofont-minus"></i>
                                    </button>
                                </span>
                                <input type="text" name="quant[1]" class="form-control input-number" value="1" min="1" max="10">
                                <span class="input-group-btn">
                                    <button type="button" class="btn btn-number" data-type="plus" data-field="quant[1]">
                                        <i class="icofont-plus"></i>
                                    </button>
                                </span>
                            </div>
                           </div>
                         </div>
                         <h6 class="cart-inline-title" style="float: left;margin: 8px;">$20.00</h6>
                       </div>
                     </div>
                  </div>
                </div>
                 <div class="cart-inline-item">
                  <div class="unit unit-spacing-sm align-items-center">
                    <div class="unit-left">
                      <a class="cart-inline-figure" href="single-product.html">
                        <img src="assets/img/product-mini-7-100x90.png" alt="" width="100" height="90">
                      </a>
                     </div>
                     <div class="unit-body w-100">
                       <h6 class="cart-inline-title mb-2">
                        <a href="single-product.html" style="color: inherit;">Bananas</a>
                      </h6>
                       <div>
                         <div class="group-xs group-middle" style="width: 135px;float: left;">
                           <div class="table-cart-stepper">
                             <div class="input-group cart-item-plus">
                                <span class="input-group-btn">
                                    <button type="button" class="btn btn-number" disabled="disabled" data-type="minus" data-field="quant[1]">
                                        <i class="icofont-minus"></i>
                                    </button>
                                </span>
                                <input type="text" name="quant[1]" class="form-control input-number" value="1" min="1" max="10">
                                <span class="input-group-btn">
                                    <button type="button" class="btn btn-number" data-type="plus" data-field="quant[1]">
                                        <i class="icofont-plus"></i>
                                    </button>
                                </span>
                            </div>
                           </div>
                         </div>
                         <h6 class="cart-inline-title" style="float: left;margin: 8px;">$20.00</h6>
                       </div>
                     </div>
                  </div>
                </div>
              </div>
              <div class="cart-inline-footer text-center">
                <div class="group-sm">
                  <a class="btn btn-lg btn-outline-dark" style="border-radius: 0px" href="cart-page.html">Go to cart</a>
                  <a class="btn btn-lg btn-success" style="border-radius: 0px" href="checkout.html">Checkout</a>
                </div>
              </div>
            </div>
          </div> 
         </li>  -->
      </ul>
    </div>
  </div>
</header>
<!-- End Header --> 