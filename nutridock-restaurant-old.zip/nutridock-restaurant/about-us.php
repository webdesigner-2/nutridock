<?php include('header.php')?>
<section class="breadcrumbs-custom">
  <div class="parallax-container" data-parallax-img="assets/img/faq-bg.jpg">
    <div class="material-parallax parallax"> <img src="assets/img/faq-bg.jpg" alt="" style="display: block; transform: translate3d(-50%, 149px, 0px);"> </div>
    <div class="breadcrumbs-custom-body parallax-content context-dark">
      <div class="container">
        <h2 class="breadcrumbs-custom-title">About Us</h2>
      </div>
    </div>
  </div>
  <div class="breadcrumbs-custom-footer">
    <div class="container">
      <ul class="breadcrumbs-custom-path">
        <li><a href="index.html">Home</a></li>
        <li><a href="grid-blog.html">Blog</a></li>
        <li class="active">About Us</li>
      </ul>
    </div>
  </div>
</section>
<main>
  <section class="section section-xl bg-default text-md-left">
    <div class="container">
      <div class="row row-40 row-md-60">
        <div class="col-md-11 col-lg-6 col-xl-5"> 
          <!-- Quote Classic Big-->
          <article class="quote-classic-big inset-xl-right-30">
            <div class="heading-3 quote-classic-big-text pt-1">
              <div class="q">New generation of farmers</div>
            </div>
          </article>
          <!-- Bootstrap tabs-->
          <div class="tabs-custom tabs-horizontal tabs-line" id="tabs-1"> 
            <!-- Nav tabs-->
            <div class="nav-tabs-wrap">
              <ul class="nav nav-tabs">
                <li class="nav-item" role="presentation"><a class="nav-link active" href="#tabs-1-1" data-toggle="tab">About</a></li>
                <li class="nav-item" role="presentation"><a class="nav-link" href="#tabs-1-2" data-toggle="tab">Our mission</a></li>
                <li class="nav-item" role="presentation"><a class="nav-link" href="#tabs-1-3" data-toggle="tab">Our goals</a></li>
              </ul>
            </div>
            <!-- Tab panes-->
            <div class="tab-content">
              <div class="tab-pane fade show active" id="tabs-1-1">
                <p>Cum nomen prarere, omnes peses amor pius, rusticus racanaes. Ubi est mirabilis gemna? Cum gabalium velum, omnes fugaes</p>
                <p>Ubi est peritus devatio? A falsis, adelphis peritus apolloniates. Est raptus clabulare, cesaris. Cum pulchritudine manducare, omnes genetrixes captis bassus</p>
              </div>
              <div class="tab-pane fade" id="tabs-1-2">
                <p>Vae. Dexter fiscina aliquando vitares animalis est. Nunquam convertam bulla. Cum pars prarere, omnes seculaes</p>
                <p>Navis dexter historia est. Luba, homo, et indictio. Emeritis eposs ducunt ad animalis. Cum solem assimilant, omnes byssuses vitare clemens, secundus nixuses.</p>
              </div>
              <div class="tab-pane fade" id="tabs-1-3">
                <p>A falsis, historia primus gallus. Est bassus tabes, cesaris. Gallus de mirabilis agripeta, locus mens! Primus ratione</p>
                <p>Cur eleates accelerare? Heu. Ecce, superbus onus! Demolitione secundus homo est. Cum cacula congregabo, omnes coordinataees acquirere dexter, flavum galataees.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-11 col-lg-6 col-xl-7">
          <div class="about-img position-relative px-4"> <img src="assets/img/about-2.jpg" alt="About Image"> <img src="assets/img/about-1.jpg" alt="About Image"> </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="heading-block border-bottom-0 text-center bottommargin-sm mb-4"> <span class="font-primary ls1 color">Processes</span>
        <h3 class="nott font-secondary ls0" style="font-size: 35px; line-height: 1.3;">How We Work</h3>
      </div>
      <div class="row clearfix">
        <div class="col-lg-3 col-sm-6 bottommargin-sm mb-3">
          <div class="feature-box media-box">
            <div class="fbox-media" style="width: 50px; height: 50px;"> <img src="assets/img/bowl.svg" alt="Image"> </div>
            <div class="fbox-content px-0">
              <h3>Food Served Hot</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptas omnis nam molestias minus ipsa!</p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6 bottommargin-sm mb-3">
          <div class="feature-box media-box">
            <div class="fbox-media" style="width: 50px; height: 50px;"> <img src="assets/img/spoon.svg" alt="Image"> </div>
            <div class="fbox-content px-0">
              <h3>Ample Options</h3>
              <p>Facere aliquam itaque quia recusandae, corporis fugit fugiat eaque, accusamus officiis reprehenderit.</p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6 bottommargin-sm mb-3">
          <div class="feature-box media-box">
            <div class="fbox-media" style="width: 50px; height: 50px;"> <img src="assets/img/glass.svg" alt="Image"> </div>
            <div class="fbox-content px-0">
              <h3>In-House Brewery</h3>
              <p>Velit id facilis odit aliquid laudantium. Tempore, sequi. Harum nesciunt, magni aperiam est?</p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6 bottommargin-sm mb-3">
          <div class="feature-box media-box">
            <div class="fbox-media" style="width: 65px; height: 50px;"> <img src="assets/img/delivery.svg" alt="Image"> </div>
            <div class="fbox-content px-0">
              <h3>In-House Brewery</h3>
              <p>Velit id facilis odit aliquid laudantium. Tempore, sequi. Harum nesciunt, magni aperiam est?</p>
            </div>
          </div>
        </div>
      </div>
      <div class="line mt-5"></div>
    </div>
    <div class="section bg-light mb-0 mt-3" style="padding: 80px 0">
      <div class="container">
        <div class="heading-block text-center mx-auto" style="max-width: 700px">
          <h2 class="mb-3"><span style="color: #6ad24e;"> Our </span> Services</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae veniam quam incidunt eos eaque esse ducimus dolore, velit, laborum dignissimos?</p>
        </div>
        <div class="clear"></div>
        <div class="row align-items-stretch justify-content-center">
          <div class="col-md-6 col-lg-4 mt-4">
            <div class="card border-0 shadow-sm h-100">
              <div class="card-body p-5">
                <div class="feature-box flex-column fbox-light fbox-plain">
                  <div class="fbox-icon mx-0 bottommargin-sm"> <img src="assets/img/award.svg" alt="Icon" style="height: 60px"> </div>
                  <div class="fbox-content">
                    <h3 class="ls0 nott mb-4">#1 Recipes Story Website</h3>
                    <p>Compellingly supply mission-critical imperatives for functional meta-services. Completely parallel task distributed materials.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mt-4">
            <div class="card border-0 shadow-sm h-100">
              <div class="card-body p-5">
                <div class="feature-box flex-column fbox-light fbox-plain">
                  <div class="fbox-icon mx-0 bottommargin-sm"> <img src="assets/img/cuisine.svg" alt="Icon" style="height: 60px"> </div>
                  <div class="fbox-content">
                    <h3 class="ls0 nott mb-4">All Type Cuisines</h3>
                    <p>Continually iterate resource-leveling applications through next-generation manufactured products. Quickly transform technically sound.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mt-4">
            <div class="card border-0 shadow-sm h-100">
              <div class="card-body p-5">
                <div class="feature-box flex-column fbox-light fbox-plain">
                  <div class="fbox-icon mx-0 bottommargin-sm"> <img src="assets/img/menu.svg" alt="Icon" style="height: 60px"> </div>
                  <div class="fbox-content">
                    <h3 class="ls0 nott mb-4">Detailed Description Menu</h3>
                    <p>Synergistically conceptualize e-business services before cross-unit methods of empowerment. Continually target collaborative.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="section topmargin-sm mb-0" style="padding: 30px 0 0; background: #F5F5F5 url('assets/img/food-pattern.png') repeat center center;">
      <div class="container clearfix">
        <div class="heading-block text-center border-bottom-0"> <span class="font-primary ls1" style="font-size: 14px; color: #AAA">Expert &amp; Skillful</span>
          <h3 class="nott font-secondary ls0" style="font-size: 45px; line-height: 1.3;">Our Chefs</h3>
        </div>
        <div class="row clearfix">
          <div class="col-lg-3 col-md-6">
            <div class="team">
              <div class="team-image imagescalein"> <a href="#"><img src="assets/img/s-1.jpg" alt="John Doe"></a> </div>
              <div class="team-desc text-left text-center text-md-left">
                <div class="team-title">
                  <h4 class="font-primary font-weight-normal ls2"><a href="#" class="text-dark">Fig Nelson</a></h4>
                  <span>Chef</span> </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rerum dolor sequi quaerat, deleniti beatae ratione.</p>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="team">
              <div class="team-image imagescalein"> <img src="assets/img/s-2.jpg" alt="Josh Clark"> </div>
              <div class="team-desc text-left text-center text-md-left">
                <div class="team-title">
                  <h4 class="font-primary font-weight-normal ls2"><a href="#" class="text-dark">Josh Clark</a></h4>
                  <span>Chef</span> </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore eveniet magnam nam, atqu.</p>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="team">
              <div class="team-image imagescalein"> <img src="assets/img/s-3.jpg" alt="Mary Jane"> </div>
              <div class="team-desc text-left text-center text-md-left">
                <div class="team-title">
                  <h4 class="font-primary font-weight-normal ls2"><a href="#" class="text-dark">Mary Jane</a></h4>
                  <span>Manager</span> </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis cum minima mollitia, velit.</p>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="team">
              <div class="team-image imagescalein"> <img src="assets/img/s-4.jpg" alt="Nix Maxwell"> </div>
              <div class="team-desc text-left text-center text-md-left">
                <div class="team-title">
                  <h4 class="font-primary font-weight-normal ls2"><a href="#" class="text-dark">Nix Maxwell</a></h4>
                  <span>Staff</span> </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facere dolore ipsam nemo, similique.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</main>
<?php include ('footer.php');?>
