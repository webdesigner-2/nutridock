<?php include('header.php')?>
<section class="breadcrumbs-custom">
    <div class="parallax-container" data-parallax-img="assets/img/faq-bg.jpg">
    	<div class="material-parallax parallax">
    		<img src="assets/img/faq-bg.jpg" alt="" style="display: block; transform: translate3d(-50%, 149px, 0px);">
    	</div>
      <div class="breadcrumbs-custom-body parallax-content context-dark">
        <div class="container">
          <h2 class="breadcrumbs-custom-title">Frequently Asked Questions</h2>
        </div>
      </div>
    </div>
    <div class="breadcrumbs-custom-footer">
      <div class="container">
        <ul class="breadcrumbs-custom-path">
          <li><a href="index.html">Home</a></li>
          <li><a href="grid-blog.html">Blog</a></li>
          <li class="active">Faq</li>
        </ul>
      </div>
    </div>
</section>
 <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq section-bg">
      <div class="container" data-aos="fade-up">
        <ul class="faq-list" data-aos="fade-up" data-aos-delay="100">
          <li>
            <a data-toggle="collapse" class="text-darkness" href="#faq1"> 
            	<span class="text-success"> 01. </span> 
            	How does the Nutridock app work?  
            	<i class="icofont-simple-up"></i>
            </a>
            <div id="faq1" class="collapse show" data-parent=".faq-list">
              <p>
                Nutridock is an intuitive nutrition app that makes it easy for you to eat better and get fitter. Here's how it works:
                <ul class="input-your-profile pl-3">
                	<li>
                		 Input your profile into the app - food preferences (vegetarian/non-vegetarian, vegan, gluten-free and more), likes and dislikes, food allergies, medical conditions and goal weight.
                	</li>
                	<li>
                		Based on the information you provide, you will get a meal plan that fits into your current lifestyle. You will have access to healthy recipes, shopping lists, immunity tips, and more. 
                	</li>
                	<li>
                		A nutrition coach will be assigned to every Nutridock Premium member, to give you a personalised diet plan and help you stay on track with tips and recommendations. 
                	</li>
                	<li>
                		The app helps you stay on track to reach your fitness goals with calorie tracking. Spend a couple of minutes after every meal logging what you ate into the food diary. Based on your log, the app will give you detailed insights and recommendations for changes you should make to help reach your goal weight. 
                	</li>
                </ul>
              </p>
            </div>
          </li>

          <li>
            <a data-toggle="collapse" href="#faq2" class="collapsed text-darkness">
            	<span class="text-success"> 02. </span> 
            	 Is weight loss guaranteed? What if this doesn't work for me? 
            	<i class="icofont-simple-up"></i>
            </a>
            <div id="faq2" class="collapse" data-parent=".faq-list">
              <p>
                At Nutridock, our philosophy is that fitness is the result of eating right, not dieting. So we will only give you nutrition recommendations that fit into your lifestyle, without being too drastic or difficult to follow. Along with these meal plans, you will also be motivated to change your daily habits to include exercise, logging all your meals, being mindful of food portions, etc. By setting realistic expectations, building healthy habits and following the prescribed meal plan religiously, we are sure you will make gradual progress. If not, our nutritionists are always on standby to answer your queries and help you succeed.
              </p>
            </div>
          </li>

          <li>
            <a data-toggle="collapse" href="#faq3" class="collapsed text-darkness">
            	<span class="text-success"> 03. </span>
            	Is this lifestyle guaranteed for a medical condition/disease I have? What if I don't see results? 
            	<i class="icofont-simple-up"></i>
            </a>
            <div id="faq3" class="collapse" data-parent=".faq-list">
              <p>
                Illnesses like diabetes, hypertension and PCOS are termed as 'lifestyle diseases' because they are often the result of faulty eating and exercise practices; apart from having a genetic predisposition. While they can be difficult to manage, the good news is that people see a drastic reduction in symptoms and are even able to stop their medication by making significant changes to their nutrition and physical activity. 
              </p>
            </div>
          </li>

          <li>
            <a data-toggle="collapse" href="#faq4" class="collapsed text-darkness">
            	<span class="text-success"> 04. </span>
            	What are the different Diet Plans I can choose?  
            	<i class="icofont-simple-up"></i>
            </a>
            <div id="faq4" class="collapse" data-parent=".faq-list">
              <p>
                Based on your nutritional and fitness goals, you can choose from these 10 diet plans
              </p>
              <div class="row pl-0">
              	<div class="col-1 pl-0 pr-0">
              		<strong>Classic</strong>
              	</div>
              	<div class="col pl-0">
              		The Classic Meal Plan follows the typical Indian diet, incorporating a varied intake of fruits, vegetables, whole grains and healthy fats. If you don't want to stray too far from a regular Indian diet, this is the plan for you. 
              	</div>
              </div>
              <div class="row pl-0">
              	<div class="col-1 pl-0 pr-0">
              		<strong>DASH</strong>
              	</div>
              	<div class="col pl-0">
              		 The DASH diet is a lifelong approach to healthy eating that's designed to help treat or prevent high blood pressure (hypertension) without medication. It focuses on fruits, vegetables, whole grains and lean meats. 
              	</div>
              </div>
              <div class="row pl-0">
              	<div class="col-1 pl-0 pr-0">
              		<strong>Pregnancy </strong>
              	</div>
              	<div class="col pl-0">
              		 The diet of a pregnant woman needs to address both the baby's development as well as her own increased nutritional needs. This meal plan focuses on aiding a healthy pregnancy with a nutritious diet that has the right balance of proteins, carbohydrates, and fats and a wide variety of vegetables, and fruits.  
              	</div>
              </div>
              <div class="row pl-0">
              	<div class="col-1 pl-0 pr-0">
              		<strong>Child Wellness </strong>
              	</div>
              	<div class="col pl-0">
              		  Children need a balanced diet with food from all 3 food groups - vegetables and fruit, whole grains and proteins. Healthy snacks are just as important as the food you serve at meals. A nutritious diet can also have a profound effect on a child's sense of mental and emotional wellbeing and helps inculcate healthy eating habits that last a lifetime. 
              	</div>
              </div>
              <div class="row pl-0">
              	<div class="col-1 pl-0 pr-0">
              		<strong>Sports Nutrition </strong>
              	</div>
              	<div class="col pl-0">
              		   Sports Nutrition plays a key role in optimising the beneficial effects of exercise, whether you’re a bodybuilder, professional athlete in training or working out to improve your mental and physical health. Focusing on nutrition and hydration can result in improved performance, injury prevention and quicker recovery  
              	</div>
              </div>
              <div class="row pl-0">
              	<div class="col-1 pl-0 pr-0">
              		<strong>Immunity-Boosting Diet</strong>
              	</div>
              	<div class="col pl-0">
              		    Feeding your body certain foods helps keep your immune system strong. This meal plan includes some powerful immune system boosters. General healthy-living strategies are a good way to strengthen your immune system. 
              	</div>
              </div>
              <div class="row pl-0">
              	<div class="col-1 pl-0 pr-0">
              		<strong>Vegan </strong>
              	</div>
              	<div class="col pl-0">
              		   The Vegan meal plan is devoid of all animal products, namely meat, eggs and dairy. You may choose to follow a vegan diet for various reasons including ethics, environmental concerns and a desire to improve health. While this diet can feel a little restrictive in the beginning, this meal plan teaches you how to create balanced, nutritious and delicious vegan meals, with all the nutrients your body needs. 
              	</div>
              </div>
              <div class="row pl-0">
              	<div class="col-1 pl-0 pr-0">
              		<strong>Gluten-Free  </strong>
              	</div>
              	<div class="col pl-0">
              		 The gluten protein found in wheat, barley, rye and triticale can trigger serious health problems or other insensitivities which present themselves as stomach pain, painful bloating and skin rashes. Going gluten-free means avoiding these grains. A gluten-free diet is essential for most people with gluten allergies or celiac disease, a condition which causes intestinal damage. 
              	</div>
              </div>
              <div class="row pl-0">
              	<div class="col-1 pl-0 pr-0">
              		<strong>Keto </strong>
              	</div>
              	<div class="col pl-0">
              		The ketogenic diet is a very low-carb, high-fat diet. It involves drastically reducing carbohydrate intake and replacing it with fat. This reduction in carbs puts your body into a metabolic state called ketosis, which is when your body becomes incredibly efficient at burning fat for energy. The Keto diet can significantly reduce blood sugar and insulin levels. 
              	</div>
              </div>
              <div class="row pl-0">
              	<div class="col-1 pl-0 pr-0">
              		<strong>Intermittent Fasting  </strong>
              	</div>
              	<div class="col pl-0">
              		Intermittent fasting (IF) involves cycling between periods of fasting and eating. It doesn’t specify which foods you should eat but rather when you should eat them while staying within your recommended calorie range. In this respect it’s an eating pattern, not a diet. Common intermittent fasting methods involve daily 16-hour fasts or fasting for 24 hours, twice per week. 
              	</div>
              </div>
            </div>
          </li>

          <li>
            <a data-toggle="collapse" href="#faq5" class="collapsed text-darkness">
            	<span class="text-success"> 05. </span>
            	Are all Nutridock programmes free to join? 
            	<i class="icofont-simple-up"></i>            	
            </a>
            <div id="faq5" class="collapse" data-parent=".faq-list">
              <p>
               Yes, anyone can get started on Nutridock for free. Once you set up your profile and tell the app all your diet preferences and fitness goals, it will give you recommendations for a meal plan, recipes, shopping lists and more.
              </p>
              <p>
              	(Click here to read 'How does the Nutridock app work?')
              </p>
              <p>
              	If you would prefer more personalised guidance, you can choose the paid plan. This will give you access to a meal plan customised just for you, one-on-one consultation with a nutritionist, macro and micronutrient tracking and much more. Click here to read about Nutridock Premium. 
              </p>
            </div>
          </li>

          <li>
            <a data-toggle="collapse" href="#faq6" class="collapsed text-darkness">
            	<span class="text-success"> 06. </span>
            	 How does the Free Plan work if there are no dedicated coaches in that plan?  
            	<i class="icofont-simple-up"></i>
            </a>
            <div id="faq6" class="collapse" data-parent=".faq-list">
              <p>
               Once you input your meal preferences, select your preferred diet plan and set your fitness goal, the app will create a meal plan for you. With a large database of caloric and nutritional value of foods, and multiple meal plans designed by diet coaches, the app can generate a meal plan for you keeping in mind your recommended calorie intake, BMI, target weight, medical conditions and food preferences
              </p>
              <p>
              	To help you stay on track on your fitness journey, you will have access to healthy recipes, calorie tracking, water tracking, shopping lists and a forum where you can discuss your progress and swap information with others on the same fitness journey. You will also get regular insights on your calorie intake and recommendations for changes you can make to ensure that you reach your goal. 
              </p>
              <p>
              	The Free Plan equips you with information and support to kickstart your fitness journey. If you feel like you could use some personalised help, you can switch to Nutridock Premium. Click here to read about the added features of this plan. 
              </p>
            </div>
          </li>

        </ul>

      </div>
    </section><!-- End Frequently Asked Questions Section -->
<?php include ('footer.php');?>