<?php include('header.php')?>
<section class="breadcrumbs-custom">
  <div class="parallax-container" data-parallax-img="assets/img/faq-bg.jpg">
    <div class="material-parallax parallax"> <img src="assets/img/faq-bg.jpg" alt="" style="display: block; transform: translate3d(-50%, 149px, 0px);"> </div>
    <div class="breadcrumbs-custom-body parallax-content context-dark">
      <div class="container">
        <h2 class="breadcrumbs-custom-title">Our Menu</h2>
      </div>
    </div>
  </div>
  <div class="breadcrumbs-custom-footer">
    <div class="container">
      <ul class="breadcrumbs-custom-path">
        <li><a href="index.php">Home</a></li>
        <li class="active">Menu</li>
      </ul>
    </div>
  </div>
</section>
<main>
   <section class="pt-0">
    <div class="container">
      <div class="row">
        <h2 class="elementor-heading-title mb-3">Top Categories</h2>
        <!-- <p class="elementor-image-box-description text-center">Lorem Ipsum is simply dummy text of the printing and</p> -->
      </div>
      <div class="row" data-aos="fade-up" data-aos-delay="100">
        <div class="col-lg-12 d-flex justify-content-center mt-3"> 
          <!-- Nav pills -->
          <ul class="nav nav-pills Categories-portfolio" role="tablist">
            <li class="nav-item"> <a class="nav-link active" data-toggle="pill" href="#Feel-Better">Feel-Better Food</a> </li>
            <li class="nav-item"> <a class="nav-link" data-toggle="pill" href="#Home-bistro">Home Bistro</a> </li>
            <li class="nav-item"> <a class="nav-link" data-toggle="pill" href="#One-Bowl">One-Bowl Nourishers</a> </li>
            <li class="nav-item"> <a class="nav-link" data-toggle="pill" href="#Takeout-twists">Takeout Twists</a> </li>
          </ul>
        </div>
        <div class="col-lg-12 d-flex justify-content-center mt-2"> 
          <!-- Tab panes -->
          <div class="tab-content w-100">
            <div id="Feel-Better" class="container tab-pane active filter-active"><br>
              <div class="row">
                <!-- <div class="col-md-3 col-sm-6">
                  <div class="product-grid2">
                      <div class="product-image2">
                          <a href="#">
                              <img class="pic-1" src="assets/img/product-img/production-meal-image-1.jpg">
                              <img class="pic-2" src="assets/img/product-img/production-meal-image-5.webp">
                          </a>
                          <ul class="social">
                              <li><a href="#" data-tip="Protein Shake"><img src="assets/img/protein-1.svg" style="width: 25px;height: 25px;" /></a></li>
                              <li><a href="#" data-tip="High Protein"><img src="assets/img/high-quality.svg" style="width: 20px;height: 25px;"/></a></li>
                              <li><a href="#" data-tip="Soy Free"><img src="assets/img/hamburger-1.svg" style="width: 23px;height: 23px;"/></i></a></li>
                              <li><a href="#" data-tip="Gluten Free"><img src="assets/img/designs-menu.svg" style="width: 20px;height: 20px;"/></i></a></li>
                          </ul>
                          <a class="add-to-cart" href="">Order Book</a>
                      </div>
                      <div class="product-content">
                          <h3 class="title Steak Peppercorn"><a href="#">Steak Peppercorn</a></h3>
                          <span class="price">with Sautéed Carrots &amp; French Green Beans</span>
                      </div>
                  </div>
              </div> -->

                <div class="col-lg-4 col-xl-3 col-md-6">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> 
                        <a href="" data-toggle="modal" data-target="#myModal-1"> 
                          <img src="assets/img/product-img/production-meal-image.jpg" class="img-fluid"> 
                        </a> 
                      </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Steak Peppercorn</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon">
                             <a href="#" class="tooltip" title="Protein Shake">  
                              <span class="tooltiptext">Protein Shake</span>
                              <img src="assets/img/protein-1.svg" alt="<500 Cal" style="width: 25px"> 
                             </a>  
                            </div>
                            <div class="meal-icon" title=""> 
                             <a href="" class="tooltip">
                             <span class="tooltiptext">High Protein</span>
                              <img src="assets/img/high-quality.svg" alt="High Protein" style="width: 25px"> 
                              </a>
                            </div>
                            <div class="meal-icon"> 
                              <a href="" class="tooltip">
                                <span class="tooltiptext">Soy Free</span> 
                                <img src="assets/img/hamburger-1.svg" alt="Soy Free" style="width: 23px"> 
                              </a>
                            </div>
                            <div class="meal-icon"> 
                              <a href="" class="tooltip" data-toggle="modal" data-target="#myModal-1">
                               <span class="tooltiptext">show more</span> 
                                <img src="assets/img/designs-menu.svg" alt="show more" style="width: 22px"> 
                              </a> 
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                 <div class="col-lg-4 col-xl-3 col-md-6">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> <a href=""> <img src="assets/img/product-img/production-meal-image.webp" class="img-fluid"> </a> </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Super Pesto & Sausage Penne</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon">
                             <a href="#" class="tooltip" title="Protein Shake">  
                              <span class="tooltiptext">Protein Shake</span>
                              <img src="assets/img/protein-1.svg" alt="<500 Cal" style="width: 25px"> 
                             </a>  
                            </div>
                            <div class="meal-icon" title=""> 
                             <a href="" class="tooltip">
                             <span class="tooltiptext">High Protein</span>
                              <img src="assets/img/high-quality.svg" alt="High Protein" style="width: 25px"> 
                              </a>
                            </div>
                            <div class="meal-icon"> 
                              <a href="" class="tooltip">
                                <span class="tooltiptext">Soy Free</span> 
                                <img src="assets/img/hamburger-1.svg" alt="Soy Free" style="width: 23px"> 
                              </a>
                            </div>
                            <div class="meal-icon"> 
                              <a href="" class="tooltip">
                               <span class="tooltiptext">show more</span> 
                                <img src="assets/img/designs-menu.svg" alt="show more" style="width: 22px"> 
                              </a> 
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4 col-xl-3 col-md-6 portfolio-item filter-bistro">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> 
                        <a href=""> <img src="assets/img/product-img/production-meal-image.jpg" class="img-fluid"> </a> 
                      </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Steak Peppercorn</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon">
                             <a href="#" class="tooltip" title="Protein Shake">  
                              <span class="tooltiptext">Protein Shake</span>
                              <img src="assets/img/protein-1.svg" alt="<500 Cal" style="width: 25px"> 
                             </a>  
                            </div>
                            <div class="meal-icon" title=""> 
                             <a href="" class="tooltip">
                             <span class="tooltiptext">High Protein</span>
                              <img src="assets/img/high-quality.svg" alt="High Protein" style="width: 25px"> 
                              </a>
                            </div>
                            <div class="meal-icon"> 
                              <a href="" class="tooltip">
                                <span class="tooltiptext">Soy Free</span> 
                                <img src="assets/img/hamburger-1.svg" alt="Soy Free" style="width: 23px"> 
                              </a>
                            </div>
                            <div class="meal-icon"> 
                              <a href="" class="tooltip">
                               <span class="tooltiptext">show more</span> 
                                <img src="assets/img/designs-menu.svg" alt="show more" style="width: 22px"> 
                              </a> 
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                 <div class="col-lg-4 col-xl-3 col-md-6">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> <a href=""> <img src="assets/img/product-img/production-meal-image.webp" class="img-fluid"> </a> </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Super Pesto & Sausage Penne</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon">
                             <a href="#" class="tooltip" title="Protein Shake">  
                              <span class="tooltiptext">Protein Shake</span>
                              <img src="assets/img/protein-1.svg" alt="<500 Cal" style="width: 25px"> 
                             </a>  
                            </div>
                            <div class="meal-icon" title=""> 
                             <a href="" class="tooltip">
                             <span class="tooltiptext">High Protein</span>
                              <img src="assets/img/high-quality.svg" alt="High Protein" style="width: 25px"> 
                              </a>
                            </div>
                            <div class="meal-icon"> 
                              <a href="" class="tooltip">
                                <span class="tooltiptext">Soy Free</span> 
                                <img src="assets/img/hamburger-1.svg" alt="Soy Free" style="width: 23px"> 
                              </a>
                            </div>
                            <div class="meal-icon"> 
                              <a href="" class="tooltip">
                               <span class="tooltiptext">show more</span> 
                                <img src="assets/img/designs-menu.svg" alt="show more" style="width: 22px"> 
                              </a> 
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div id="Home-bistro" class="container tab-pane fade"><br>
              <div class="row" data-aos="fade-up" data-aos-delay="200">
                <div class="col-lg-4 col-xl-3 col-md-6">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> <a href=""> <img src="assets/img/product-img/production-meal-image.webp" class="img-fluid"> </a> </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Super Pesto & Sausage Penne</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon" data-toggle="tooltip" data-placement="top" title="Hooray!"> <img src="assets/img/protein-shake.svg" alt="<500 Cal"> </div>
                            <div class="meal-icon" title=""> <img src="assets/img/hamburger.svg" alt="High Protein"> </div>
                            <div class="meal-icon"> <img src="assets/img/vegetables.svg" alt="Soy Free"> </div>
                            <div class="meal-icon" > <img src="assets/img/tool-menu.svg" alt="show more"> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4 col-xl-3 col-md-6  portfolio-item filter-app">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> <a href=""> <img src="assets/img/product-img/production-meal-image-4.webp" class="img-fluid"> </a> </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Steak Peppercorn</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon" data-toggle="tooltip" data-placement="top" title="Hooray!"> <img src="assets/img/protein-shake.svg" alt="<500 Cal"> </div>
                            <div class="meal-icon" title=""> <img src="assets/img/hamburger.svg" alt="High Protein"> </div>
                            <div class="meal-icon"> <img src="assets/img/vegetables.svg" alt="Soy Free"> </div>
                            <div class="meal-icon" > <img src="assets/img/tool-menu.svg" alt="show more"> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div id="One-Bowl" class="container tab-pane fade"><br>
              <div class="row" data-aos="fade-up" data-aos-delay="200">
                <div class="col-lg-4 col-xl-3 col-md-6">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> <a href=""> <img src="assets/img/product-img/production-meal-image.webp" class="img-fluid"> </a> </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Super Pesto & Sausage Penne</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon" data-toggle="tooltip" data-placement="top" title="Hooray!"> <img src="assets/img/protein-shake.svg" alt="<500 Cal"> </div>
                            <div class="meal-icon" title=""> <img src="assets/img/hamburger.svg" alt="High Protein"> </div>
                            <div class="meal-icon"> <img src="assets/img/vegetables.svg" alt="Soy Free"> </div>
                            <div class="meal-icon" > <img src="assets/img/tool-menu.svg" alt="show more"> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4 col-xl-3 col-md-6  portfolio-item filter-app">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> <a href=""> <img src="assets/img/product-img/production-meal-image-4.webp" class="img-fluid"> </a> </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Steak Peppercorn</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon" data-toggle="tooltip" data-placement="top" title="Hooray!"> <img src="assets/img/protein-shake.svg" alt="<500 Cal"> </div>
                            <div class="meal-icon" title=""> <img src="assets/img/hamburger.svg" alt="High Protein"> </div>
                            <div class="meal-icon"> <img src="assets/img/vegetables.svg" alt="Soy Free"> </div>
                            <div class="meal-icon" > <img src="assets/img/tool-menu.svg" alt="show more"> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div id="Takeout-twists" class="container tab-pane fade"><br>
              <div class="row" data-aos="fade-up" data-aos-delay="200">
                <div class="col-lg-4 col-xl-3 col-md-6">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> <a href=""> <img src="assets/img/product-img/production-meal-image.webp" class="img-fluid"> </a> </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Super Pesto & Sausage Penne</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon" data-toggle="tooltip" data-placement="top" title="Hooray!"> <img src="assets/img/protein-shake.svg" alt="<500 Cal"> </div>
                            <div class="meal-icon" title=""> <img src="assets/img/hamburger.svg" alt="High Protein"> </div>
                            <div class="meal-icon"> <img src="assets/img/vegetables.svg" alt="Soy Free"> </div>
                            <div class="meal-icon" > <img src="assets/img/tool-menu.svg" alt="show more"> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4 col-xl-3 col-md-6  portfolio-item filter-app">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> <a href=""> <img src="assets/img/product-img/production-meal-image-4.webp" class="img-fluid"> </a> </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Steak Peppercorn</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon" data-toggle="tooltip" data-placement="top" title="Hooray!"> <img src="assets/img/protein-shake.svg" alt="<500 Cal"> </div>
                            <div class="meal-icon" title=""> <img src="assets/img/hamburger.svg" alt="High Protein"> </div>
                            <div class="meal-icon"> <img src="assets/img/vegetables.svg" alt="Soy Free"> </div>
                            <div class="meal-icon" > <img src="assets/img/tool-menu.svg" alt="show more"> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  </section>
</main>
 <!-- The Modal -->
  <div class="modal" id="myModal-1">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h3 class="modal-title">Steak Peppercorn </h3>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body" style="background-color: #f7f7f7;">
          <div>
            <ul class="list-inline mb-0" data-test="tags">
              <li class="list-inline-item mr-1 mb-1"><span class="badge-list-item">&lt;500 Cal</span></li>
              <li class="list-inline-item mr-1 mb-1"><span class="badge-list-item">Gluten Free</span></li>
              <li class="list-inline-item mr-1 mb-1"><span class="badge-list-item">&lt;35g Carbs</span></li>
              <li class="list-inline-item mr-1 mb-1"><span class="badge-list-item">High Protein</span></li>
              <li class="list-inline-item mr-1 mb-1"><span class="badge-list-item">Soy Free</span></li>
            </ul>
          </div>
          <div class="MealModal-module">
            <article class="meals-overlay">
             <div>
               <div class="row">
                 <div class="col-md-5">
                   <div class="position-relative">
                     <img class="mb-3 w-100" src="https://res.cloudinary.com/freshly/image/upload/c_fill,dpr_2,f_auto,w_580/v1589575861/production-meal-image-09d83596-0409-4e39-9b3b-9b512c12c6e1.jpg">
                   </div>
                   <div class="position-relative">
                     <img class="mb-3 w-100" src="https://res.cloudinary.com/freshly/image/upload/c_fill,dpr_2,f_auto,w_580/v1574619598/production-meal-image-7424ee00-d9d6-4038-b190-a5d22da8ac56.jpg">
                   </div>
                   <div class="position-relative">
                     <img class="mb-3 w-100" src="https://res.cloudinary.com/freshly/image/upload/c_fill,dpr_2,f_auto,w_580/v1574619627/production-meal-image-17aa62ca-008b-4680-a2d7-4b274820065b.jpg">
                   </div>
                   <div class="position-relative">
                     <img class="mb-3 w-100" src="https://res.cloudinary.com/freshly/image/upload/c_fill,dpr_2,f_auto,w_580/v1574619652/production-meal-image-d09b8cb8-70ef-4b0d-8995-59420fc8c9da.jpg">
                   </div>
                   <div class="position-relative">
                     <img class="mb-3 w-100" src="https://res.cloudinary.com/freshly/image/upload/c_fill,dpr_2,f_auto,w_580/v1589575861/production-meal-image-09d83596-0409-4e39-9b3b-9b512c12c6e1.jpg">
                   </div>
                 </div>

                 <div class="col-md-7">
                  <section class="title-wrap">
                   <div class="heading-title-">
                     <h2 class="pl-3">What makes this dish special</h2>
                     <ul class="list-unstyled ml-n3 mb-0">
                       <li class="MealDetails-List pl-3 mb-4">
                         Juicy, oven-roasted chicken breast marinated in fragrant Italian herbs
                       </li>
                       <li class="MealDetails-List pl-3 mb-4">
                         Juicy, oven-roasted chicken breast marinated in fragrant Italian herbs
                       </li>
                       <li class="MealDetails-List pl-3 mb-4">
                         Juicy, oven-roasted chicken breast marinated in fragrant Italian herbs
                       </li>
                       <li class="MealDetails-List pl-3 mb-4">
                         Juicy, oven-roasted chicken breast marinated in fragrant Italian herbs
                       </li>
                     </ul>
                   </div>
                  </section> 

                  <section class="title-wrap">
                     <div class="heading-title-">
                       <h2 class="pl-3">Ingredients</h2>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <figure class="text-center">
                          <img class="Ingredients-img" alt="Chicken Breast" src="https://res.cloudinary.com/freshly/image/upload/c_fit,f_auto,h_300,w_300/v1557431212/production-image-3b1cc8ff-85dd-4dbd-be6d-f06a6e2ce0b3.png">
                          <figcaption class="Ingredients-title">Chicken Breast</figcaption>
                        </figure>
                      </div>
                      <div class="col-md-4">
                        <figure class="text-center">
                          <img class="Ingredients-img" alt="Chicken Breast" src="https://res.cloudinary.com/freshly/image/upload/c_fit,f_auto,h_300,w_300/v1544802880/production-image-11b08e84-b9f0-4a04-846c-4ac08fe0311b.png">
                          <figcaption class="Ingredients-title">Chicken Breast</figcaption>
                        </figure>
                      </div>
                      <div class="col-md-4">
                        <figure class="text-center">
                          <img class="Ingredients-img" alt="Chicken Breast" src="https://res.cloudinary.com/freshly/image/upload/c_fit,f_auto,h_300,w_300/v1545160945/production-image-8b009f04-d094-4396-9dc6-5f45fcd5c3fc.png">
                          <figcaption class="Ingredients-title">Chicken Breast</figcaption>
                        </figure>
                      </div>
                    </div>
                    <button class="show-all-ingredients" aria-expanded="false" aria-controls="ingredientsCollapsible">
                      Show all ingredients
                    </button>
                  </section>

                   <section class="title-wrap">
                    <div class="px-3">
                     <div class="heading-title-">
                       <h2 class="pl-0">What’s inside</h2>
                    </div>
                    <div class="row mb-4">
                      <div class="col-md-6">
                        <div class="Featured-Nutridock-module">
                          <span class="Calories-name">Calories</span>
                          <strong class="d-block">440</strong>
                          <div class="progress" style="height: 0.3rem;">
                            <div class="progress-bar bg-primary" style="width:40%"></div>
                          </div>
                          <small>25DV</small>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="Featured-Nutridock-module border-0">
                          <span class="Calories-name">Carbs</span>
                          <strong class="d-block">440</strong>
                          <div class="progress" style="height: 0.3rem;">
                            <div class="progress-bar bg-success" style="width:60%"></div>
                          </div>
                          <small>25DV</small>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="Featured-Nutridock-module pt-4" style="border-top: 1px solid #e1e1e1;">
                          <span class="Calories-name">Total Fat</span>
                          <strong class="d-block">170Kg</strong>
                          <div class="progress" style="height: 0.3rem;">
                            <div class="progress-bar bg-success" style="width:60%"></div>
                          </div>
                          <small>25DV</small>
                        </div>
                      </div>
                    </div>
                    <button class="show-all-ingredients" aria-expanded="false" aria-controls="ingredientsCollapsible">
                      Show all ingredients
                    </button>
                  </div>
                </section>
               </div>
             </div> 
            </article>
          </div>
        </div>
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>

      </div>
    </div>
  </div>
<?php include('footer.php');?>