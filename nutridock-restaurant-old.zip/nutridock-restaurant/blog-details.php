<?php include('header.php')?>
	<section class="breadcrumbs-custom">
        <div class="parallax-container" data-parallax-img="assets/img/bg-blog.jpg">
        	<div class="material-parallax parallax">
        		<img src="assets/img/bg-blog.jpg" alt="" style="display: block; transform: translate3d(-50%, 149px, 0px);">
        	</div>
          <div class="breadcrumbs-custom-body parallax-content context-dark">
            <div class="container">
              <h2 class="breadcrumbs-custom-title">Blog Post</h2>
            </div>
          </div>
        </div>
        <div class="breadcrumbs-custom-footer">
          <div class="container">
            <ul class="breadcrumbs-custom-path">
              <li><a href="index.html">Home</a></li>
              <li><a href="grid-blog.html">Blog</a></li>
              <li class="active">Blog Post</li>
            </ul>
          </div>
        </div>
      </section>

      <main class="mb-4">   
      <section class="section section-xl bg-default text-md-left">
        <div class="container">
          <div class="row row-50 row-md-60">
            <div class="col-lg-8 col-xl-9">
               <div class="inset-xl-right-70">
                 <div class="row row-50 row-md-60 row-lg-80 row-xl-100">
                  <div class="col-12">
                    <!-- Post Modern-->
                    <article class="post post-modern box-xxl">
                      <div class="post-modern-panel">
                        <div><a class="post-modern-tag" href="#">Organic food</a></div>
                        <div>
                          <time class="post-modern-time" datetime="2020-08-09">August 9, 2020</time>
                        </div>
                      </div>
                      <h3 class="post-modern-title"><a href="blog-details.php">How can salmon be raised organically in fish farms?</a></h3><a class="post-modern-figure" href="blog-details.php"><img src="assets/img/post-7-800x394.jpg" alt="" width="800" height="394"></a>
                      <p class="post-modern-text">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet</p>
                      <p class="post-modern-text">At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Stet clita kasd gubergren, no sea takimata sanctus est</p>
                    </article>
                    <article class="quote-classic quote-classic-2">
                      <div class="quote-classic-text">
                        <div class="q">There are a few ways to raise an organic salmon at a fish farm and they proved to be successful.</div>
                      </div>
                    </article>
                    <p>Cum bulla messis, omnes mineralises gratia camerarius, emeritis apolloniateses. Equiso de bi-color burgus, examinare lapsus! Accola gratis usus est. Speciess sunt equisos de emeritis calceus. Vae. Vortexs mori in tubinga! Sunt quadraes amor bi-color, fatalis medicinaes. Cum scutum resistere, omnes imberes locus</p>
                    <div class="single-post-bottom-panel">
                      <div class="group-sm group-justify">
                        <div>
                          <div class="group-sm group-tags"><a class="link-tag" href="#">Fruits</a><a class="link-tag" href="#">Vegetables</a><a class="link-tag" href="#">Drinks</a></div>
                        </div>
                        <div>
                          <div class="group-xs group-middle"><span class="list-social-title">Share</span>
                            <div>
                              <ul class="list-inline list-social list-inline-sm">
                                <li><a class="icon mdi mdi-facebook" href="#"><i class="icofont-facebook"></i></a></li>
                                <li><a class="icon mdi mdi-twitter" href="#"><i class="icofont-twitter"></i></a></li>
                                <li><a class="icon mdi mdi-instagram" href="#"><i class="icofont-instagram"></i></a></li>
                                <li><a class="icon mdi mdi-google-plus" href="#"><i class="icofont-google-plus"></i></a></li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="mb-3">
                    <h3 class="text-dark">Top 9 Benefits of Cabbage</h3>
                    <p class="lead">Check out the 9 good reasons, why cabbage deserves a place in your plate:</p>
                    <h5 class="mt-2 mb-2" style="font-family: 'Ruda', sans-serif;color: #333;">#1 Good for your gut</h5>
                    <img src="assets/img/cabbage-happy-gut.jpg" class="img-fluid d-block mx-auto mt-4 mb-3">
                    <p class="mt-2">With cabbage being high in fiber and water content, it helps propel food through your digestive tract and aid normal bowel movement. It is even healthier if cabbage is consumed in fermented form where it acts as a probiotic, rich in good bacteria which keeps the gut healthy. Cabbage also helps relieve symptoms of gastritis (inflammation in stomach wall), stomach ulcers, and irritable bowel syndrome  (ulcerative colitis and Crohn’s disease) due to its high fiber content.</p>
                   </div>
                    <div class="mb-3">
                    <h5 class="mt-2 mb-2" style="font-family: 'Ruda', sans-serif;color: #333;">#2 Keeps your heart healthy</h5>
                    <img src="assets/img/cabbage-healthy-heart.jpg" class="img-fluid d-block mx-auto mt-4 mb-3">
                    <p class="mt-2">With cabbage being high in fiber and water content, it helps propel food through your digestive tract and aid normal bowel movement. It is even healthier if cabbage is consumed in fermented form where it acts as a probiotic, rich in good bacteria which keeps the gut healthy. Cabbage also helps relieve symptoms of gastritis (inflammation in stomach wall), stomach ulcers, and irritable bowel syndrome  (ulcerative colitis and Crohn’s disease) due to its high fiber content.</p>
                   </div>
                   <div class="mb-3">
                    <h5 class="mt-2 mb-2" style="font-family: 'Ruda', sans-serif;color: #333;">#3 Eat Cabbage for brain health</h5>
                    <img src="assets/img/cabbage-healthy-brain.jpg" class="img-fluid d-block mx-auto mt-4 mb-3">
                    <p class="mt-2">With cabbage being high in fiber and water content, it helps propel food through your digestive tract and aid normal bowel movement. It is even healthier if cabbage is consumed in fermented form where it acts as a probiotic, rich in good bacteria which keeps the gut healthy. Cabbage also helps relieve symptoms of gastritis (inflammation in stomach wall), stomach ulcers, and irritable bowel syndrome  (ulcerative colitis and Crohn’s disease) due to its high fiber content.</p>
                   </div>
                    <div class="mb-3">
                      <h5 class="mt-2 mb-2" style="font-family: 'Ruda', sans-serif;color: #333;">#4 Immunity Booster</h5>
                      <p class="mt-2">High vitamin C content in cabbage imparts immunity-boosting property to it. A strong immune system fights against diseases by killing harmful bacteria and viruses and helps you stay healthy. </p>
                    </div>
                    <div class="mb-3">
                      <h5 class="mt-2 mb-2" style="font-family: 'Ruda', sans-serif;color: #333;">#5 Helps keep Cancer at bay</h5>
                      <p class="mt-2">Studies have shown that consumption of cruciferous vegetables lower the risk of certain types of cancers including cancer of colon, breast, lungs, and prostate. Anti-cancer property of cabbage is due to its rich content of nutrients like glucosinolates, antioxidants, and anti-inflammatory agents. Sulforaphane, lupeol, and sinigrin found in cabbage help fight cancer cells. A powerful antioxidant called anthocyanin which is abundantly present in red cabbage is shown to have anti-cancer properties as it not only destroys already formed cancer cells but also prevents the formation of new cancer cells in the body. </p>
                    </div>
                  </div>

                  <div class="col-12">
                    <h6 class="single-post-title">Related Posts</h6>
                    <div class="row row-30">
                      <div class="col-sm-6">
                        <!-- Post Classic-->
                        <article class="post post-classic box-md"><a class="post-classic-figure" href="blog-post.html"><img src="assets/img/post-1-370x239.jpg" alt="" width="370" height="239"></a>
                          <div class="post-classic-content">
                            <div class="post-classic-time">
                              <time datetime="2020-09-08">August 9, 2020</time>
                            </div>
                            <h5 class="post-classic-title"><a href="blog-post.html">Top 5 Easy and Cheap Organic Breakfast Recipes</a></h5>
                            <p class="post-classic-text">Est velox nuptia, cesaris. Est dexter turpis, cesaris. Cum nixus persuadere, omnes fluctuies promissio flavum</p>
                          </div>
                        </article>
                      </div>
                      <div class="col-sm-6">
                        <!-- Post Classic-->
                        <article class="post post-classic box-md"><a class="post-classic-figure" href="blog-post.html"><img src="assets/img/post-2-370x239.jpg" alt="" width="370" height="239"></a>
                          <div class="post-classic-content">
                            <div class="post-classic-time">
                              <time datetime="2020-09-08">August 9, 2020</time>
                            </div>
                            <h5 class="post-classic-title"><a href="blog-post.html">Everyday Dinner Choices for a Healthier, Happier You</a></h5>
                            <p class="post-classic-text">Sensorems peregrinatione in rugensis civitas! Ubi est bi-color byssus? Velox, teres ollas recte aperto de castus</p>
                          </div>
                        </article>
                      </div>
                    </div>
                  </div>
                  <div class="col-12">
                    <h6 class="single-post-title">3 Comments</h6>
                    <div class="box-comment">
                      <div class="unit flex-column flex-sm-row unit-spacing-md">
                        <div class="unit-left"><a class="box-comment-figure" href="#"><img src="assets/img/user-1-119x119.jpg" alt="" width="119" height="119"></a></div>
                        <div class="unit-body">
                          <div class="group-sm group-justify">
                            <div>
                              <div class="group-xs group-middle">
                                <h5 class="box-comment-author"><a href="#">Jane Doe</a></h5><a class="box-comment-reply" href="#">Reply</a>
                              </div>
                            </div>
                            <div class="box-comment-time">
                              <time datetime="2020-08-30">Aug 30, 2020</time>
                            </div>
                          </div>
                          <p class="box-comment-text">Lorem ipsum dolor sit amet, has mutat labores nostrum ei. Duo te blandit erroribus, ut sea ipsum nonumy, mel no ignota accusamus gloriatur. Id has habeo regione, explicari hendrerit reprimique cum te.</p>
                        </div>
                      </div>
                      <div class="box-comment">
                        <div class="unit flex-column flex-sm-row unit-spacing-md">
                          <div class="unit-left"><a class="box-comment-figure" href="#"><img src="assets/img/user-2-119x119.jpg" alt="" width="119" height="119"></a></div>
                          <div class="unit-body">
                            <div class="group-sm group-justify">
                              <div>
                                <div class="group-xs group-middle">
                                  <h5 class="box-comment-author"><a href="#">Jessica Brown</a></h5><a class="box-comment-reply" href="#">Reply</a>
                                </div>
                              </div>
                              <div class="box-comment-time">
                                <time datetime="2020-08-30">Aug 30, 2020</time>
                              </div>
                            </div>
                            <p class="box-comment-text">Lorem ipsum dolor sit amet, has mutat labores nostrum ei. Duo te blandit erroribus, ut sea ipsum nonumy, mel no ignota accusamus</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="box-comment">
                      <div class="unit flex-column flex-sm-row unit-spacing-md">
                        <div class="unit-left"><a class="box-comment-figure" href="#"><img src="assets/img/user-3-119x119.jpg" alt="" width="119" height="119"></a></div>
                        <div class="unit-body">
                          <div class="group-sm group-justify">
                            <div>
                              <div class="group-xs group-middle">
                                <h5 class="box-comment-author"><a href="#">Nick Stevens</a></h5><a class="box-comment-reply" href="#">Reply</a>
                              </div>
                            </div>
                            <div class="box-comment-time">
                              <time datetime="2020-08-30">Aug 30, 2020</time>
                            </div>
                          </div>
                          <p class="box-comment-text">Lorem ipsum dolor sit amet, has mutat labores nostrum ei. Duo te blandit erroribus, ut sea ipsum nonumy, mel no ignota accusamus gloriatur. Id has habeo regione, explicari hendrerit reprimique cum te.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-12">
                    <h6 class="single-post-title">Leave a comment</h6>
                    <form action="forms/contact.php" method="post" role="form" class="php-email-form">
                      <div class="form-row row">
                        <div class="col col-md-6 mb-3 form-group">
                          <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars">
                          <div class="validate"></div>
                        </div>
                        <div class="col col-md-6 mb-3 form-group">
                          <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email">
                          <div class="validate"></div>
                        </div>
                      </div>
                     
                      <div class="form-group mt-3 mb-3">
                        <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                        <div class="validate"></div>
                      </div>
                      
                      <div class="text-left"><button type="submit" class="button">Send Message</button></div>
                    </form>
                  </div>
                 </div>
               </div>
            </div>
            <div class="col-lg-4 col-xl-3">
              <div class="aside row row-30 row-md-50 justify-content-md-between">
                <div class="aside-item col-12">
                  <div class="team-info box-sm"><a class="team-info-figure" href="#"><img src="assets/img/user-4-123x123.jpg" alt="" width="123" height="123"></a>
                    <h6 class="team-info-title"><a href="#">Caroline Lopez</a></h6>
                    <p class="team-info-text">I am the leading editor and blogger at Farm website.</p>
                  </div>
                </div>
                <div class="aside-item col-sm-6 col-md-5 col-lg-12">
                  <h6 class="aside-title">Categories</h6>
                  <ul class="list-categories">
                    <li><a href="#">News</a><span class="list-categories-number">(18)</span></li>
                    <li><a href="#">Organic Food</a><span class="list-categories-number">(9)</span></li>
                    <li><a href="#">Health</a><span class="list-categories-number">(5)</span></li>
                    <li><a href="#">Smoothies</a><span class="list-categories-number">(8)</span></li>
                  </ul>
                </div>
                <div class="aside-item col-sm-6 col-lg-12">
                  <h6 class="aside-title">Latest Posts</h6>
                  <div class="row row-20 row-lg-30 gutters-10 mt-4">
                    <div class="col-6 col-lg-12">
                      <!-- Post Minimal-->
                      <article class="post post-minimal">
                        <div class="unit unit-spacing-sm flex-column flex-lg-row align-items-lg-center">
                          <div class="unit-left"><a class="post-minimal-figure" href="blog-details.php">
                            <img src="assets/img/post-mini-1-106x104.jpg" alt="" width="106" height="104"></a>
                          </div>
                          <div class="unit-body">
                            <p class="post-minimal-title"><a href="blog-details.php">Why Organic Food is Full of Benefits</a></p>
                            <div class="post-minimal-time">
                              <time datetime="2020-03-15">March 15, 2020</time>
                            </div>
                          </div>
                        </div>
                      </article>
                    </div>
                    <div class="col-6 col-lg-12">
                      <!-- Post Minimal-->
                      <article class="post post-minimal">
                        <div class="unit unit-spacing-sm flex-column flex-lg-row align-items-lg-center">
                          <div class="unit-left"><a class="post-minimal-figure" href="blog-details.php">
                            <img src="assets/img/post-mini-2-106x104.jpg" alt="" width="106" height="104"></a>
                          </div>
                          <div class="unit-body">
                            <p class="post-minimal-title">
                              <a href="blog-details.php">5 Perfect Fruits for Breakfast</a>
                            </p>
                            <div class="post-minimal-time">
                              <time datetime="2020-03-15">March 15, 2020</time>
                            </div>
                          </div>
                        </div>
                      </article>
                    </div>
                  </div>
                </div>
                <div class="aside-item col-sm-6 col-md-5 col-lg-12">
                  <h6 class="aside-title">Popular tags</h6>
                  <div class="group-sm group-tags">
                    <a class="link-tag" href="#">Fruits</a>
                    <a class="link-tag" href="#">Vegetables</a>
                    <a class="link-tag" href="#">Drinks</a>
                    <a class="link-tag" href="#">Organic</a>
                    <a class="link-tag" href="#">Food</a>
                    <a class="link-tag" href="#">Smoothies</a>
                  </div>
                </div>
                <div class="aside-item col-sm-6 col-lg-12">
                  <h6 class="aside-title">Archives</h6>
                  <ul class="list-marked list-archives d-inline-block d-md-block">
                    <li><a href="#">March 2020</a></li>
                    <li><a href="#">February 2020</a></li>
                    <li><a href="#">January 2020</a></li>
                    <li><a href="#">December 2020</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>

<?php include('footer.php')?>