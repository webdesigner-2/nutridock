<?php include('header.php')?>
	<section class="breadcrumbs-custom">
        <div class="parallax-container" data-parallax-img="assets/img/bg-blog.jpg">
        	<div class="material-parallax parallax">
        		<img src="assets/img/bg-blog.jpg" alt="" style="display: block; transform: translate3d(-50%, 149px, 0px);">
        	</div>
          <div class="breadcrumbs-custom-body parallax-content context-dark">
            <div class="container">
              <h2 class="breadcrumbs-custom-title">Blog List</h2>
            </div>
          </div>
        </div>
        <div class="breadcrumbs-custom-footer">
          <div class="container">
            <ul class="breadcrumbs-custom-path">
              <li><a href="index.html">Home</a></li>
              <li><a href="grid-blog.html">Blog</a></li>
              <li class="active">Blog List</li>
            </ul>
          </div>
        </div>
      </section>
   <main>   
      <section class="section section-xl bg-default text-md-left">
        <div class="container">
          <div class="row row-50 row-md-60">
            <div class="col-lg-8 col-xl-9">
              <div class="inset-xl-right-70">
                <div class="row row-50 row-md-60 row-lg-80 row-xl-100">
                  <div class="col-12">
                    <!-- Post Modern-->
                    <article class="post post-modern box-xxl">
                      <div class="post-modern-panel">
                        <div><a class="post-modern-tag" href="#">Organic food</a></div>
                        <div>
                          <time class="post-modern-time" datetime="2020-08-09">August 9, 2020</time>
                        </div>
                      </div>
                      <h3 class="post-modern-title"><a href="blog-details.php">How can salmon be raised organically in fish farms?</a></h3><a class="post-modern-figure" href="blog-details.php"><img src="assets/img/post-7-800x394.jpg" alt="" width="800" height="394"></a>
                      <p class="post-modern-text">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet</p><a class="post-modern-link" href="blog-details.php">Read more</a>
                    </article>
                  </div>
                  <div class="col-12">
                    <!-- Post Modern-->
                    <article class="post post-modern box-xxl">
                      <div class="post-modern-panel">
                        <div><a class="post-modern-tag" href="#">Organic food</a></div>
                        <div>
                          <time class="post-modern-time" datetime="2020-08-09">August 9, 2020</time>
                        </div>
                      </div>
                      <h3 class="post-modern-title"><a href="blog-details.php">Great bulk recipes to help use all your organic vegetables</a></h3><a class="post-modern-figure" href="blog-details.php"><img src="assets/img/post-8-800x394.jpg" alt="" width="800" height="394"></a>
                      <p class="post-modern-text">Cur abaculus ire? Exsul secundus historia est. Hilotaes persuadere! Est teres exemplar, cesaris. Altus hydras ducunt ad repressor. Pol, animalis! Rationes sunt abactors de ferox ignigena. Nunquam imperium cannabis. Hercle, magister audax!, hibrida! Accentors studere, tanquam mirabilis tumultumque. Vae, barbatus detrius!</p><a class="post-modern-link" href="blog-details.php">Read more</a>
                    </article>
                  </div>
                  <div class="col-12">
                    <!-- Post Modern-->
                    <article class="post post-modern box-xxl">
                      <div class="post-modern-panel">
                        <div><a class="post-modern-tag" href="#">Organic food</a></div>
                        <div>
                          <time class="post-modern-time" datetime="2020-08-09">August 9, 2020</time>
                        </div>
                      </div>
                      <h3 class="post-modern-title"><a href="blog-details.php">Standardizing the Organic Industry in the USA</a></h3><a class="post-modern-figure" href="blog-details.php"><img src="assets/img/post-9-800x394.jpg" alt="" width="800" height="394"></a>
                      <p class="post-modern-text">Capios persuadere in oenipons! Hercle, sensorem peritus!, bassus poeta! Solem de bi-color competition, gratia resistentia! Ubi est gratis silva? Nunquam transferre ignigena. Verpa noceres, tanquam festus zirbus. A falsis, barcas peritus calcaria. Humani generiss messis! Eheu, noster bubo! Cum musa credere, omnes lacteaes</p><a class="post-modern-link" href="blog-details.php">Read more</a>
                    </article>
                  </div>
                </div>
                <div class="pagination-wrap">
                  <!-- Bootstrap Pagination-->
                  <nav aria-label="Page navigation">
                    <ul class="pagination">
                      <li class="page-item page-item-control disabled">
                      	<a class="page-link" href="#" aria-label="Previous">
                      		<i class="icofont-arrow-left" style="font-size: 25px"></i>
                      	</a>
                      </li>
                      <li class="page-item active"><span class="page-link">1</span></li>
                      <li class="page-item"><a class="page-link" href="#">2</a></li>
                      <li class="page-item"><a class="page-link" href="#">3</a></li>
                      <li class="page-item page-item-control">
                      	<a class="page-link" href="#" aria-label="Next">
                      		<i class="icofont-arrow-right" style="font-size: 25px"></i>
                      	</a>
                      </li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-xl-3">
              <div class="aside row row-30 row-md-50 justify-content-md-between">
                <div class="aside-item col-12">
                  <div class="team-info box-sm"><a class="team-info-figure" href="#"><img src="assets/img/user-4-123x123.jpg" alt="" width="123" height="123"></a>
                    <h6 class="team-info-title"><a href="#">Caroline Lopez</a></h6>
                    <p class="team-info-text">I am the leading editor and blogger at Farm website.</p>
                  </div>
                </div>
                <div class="aside-item col-sm-6 col-md-5 col-lg-12">
                  <h6 class="aside-title">Categories</h6>
                  <ul class="list-categories">
                    <li><a href="#">News</a><span class="list-categories-number">(18)</span></li>
                    <li><a href="#">Organic Food</a><span class="list-categories-number">(9)</span></li>
                    <li><a href="#">Health</a><span class="list-categories-number">(5)</span></li>
                    <li><a href="#">Smoothies</a><span class="list-categories-number">(8)</span></li>
                  </ul>
                </div>
                <div class="aside-item col-sm-6 col-lg-12">
                  <h6 class="aside-title">Latest Posts</h6>
                  <div class="row row-20 row-lg-30 gutters-10 mt-4">
                    <div class="col-6 col-lg-12">
                      <!-- Post Minimal-->
                      <article class="post post-minimal">
                        <div class="unit unit-spacing-sm flex-column flex-lg-row align-items-lg-center">
                          <div class="unit-left"><a class="post-minimal-figure" href="blog-details.php">
                          	<img src="assets/img/post-mini-1-106x104.jpg" alt="" width="106" height="104"></a>
                          </div>
                          <div class="unit-body">
                            <p class="post-minimal-title"><a href="blog-details.php">Why Organic Food is Full of Benefits</a></p>
                            <div class="post-minimal-time">
                              <time datetime="2020-03-15">March 15, 2020</time>
                            </div>
                          </div>
                        </div>
                      </article>
                    </div>
                    <div class="col-6 col-lg-12">
                      <!-- Post Minimal-->
                      <article class="post post-minimal">
                        <div class="unit unit-spacing-sm flex-column flex-lg-row align-items-lg-center">
                          <div class="unit-left"><a class="post-minimal-figure" href="blog-details.php">
                          	<img src="assets/img/post-mini-2-106x104.jpg" alt="" width="106" height="104"></a>
                          </div>
                          <div class="unit-body">
                            <p class="post-minimal-title">
                            	<a href="blog-details.php">5 Perfect Fruits for Breakfast</a>
                            </p>
                            <div class="post-minimal-time">
                              <time datetime="2020-03-15">March 15, 2020</time>
                            </div>
                          </div>
                        </div>
                      </article>
                    </div>
                  </div>
                </div>
                <div class="aside-item col-sm-6 col-md-5 col-lg-12">
                  <h6 class="aside-title">Popular tags</h6>
                  <div class="group-sm group-tags">
                  	<a class="link-tag" href="#">Fruits</a>
                  	<a class="link-tag" href="#">Vegetables</a>
                  	<a class="link-tag" href="#">Drinks</a>
                  	<a class="link-tag" href="#">Organic</a>
                  	<a class="link-tag" href="#">Food</a>
                  	<a class="link-tag" href="#">Smoothies</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>  
<?php include('footer.php')?>