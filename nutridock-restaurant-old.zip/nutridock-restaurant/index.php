<?php include('header.php')?>
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active"> <img src="assets/img/slider-1.png" class="d-block w-100" alt="...">
      <div class="carousel-caption text-left">
        <div class="container" data-aos="zoom-out" data-aos-delay="100">
          <h1 class="slider-containt">The Soul Food and Bistro</h1>
          <p>The Chef creates divine combinations</p>
          <div class="d-flex"> <!-- <a href="#about" class="btn-get-started scrollto">Shop Now</a> --> 
            <a href="#" class="cta">
                <span>Shop Now</span>
                <svg width="13px" height="10px" viewBox="0 0 13 10">
                  <path d="M1,5 L11,5"></path>
                  <polyline points="8 1 12 5 8 9"></polyline>
                </svg>
              </a>
          </div>
        </div>
      </div>
    </div>
    <div class="carousel-item"> <img src="assets/img/slider-2.png" class="d-block w-100" alt="..."> </div>
    <div class="carousel-item"> <img src="assets/img/slider-3.png" class="d-block w-100" alt="...">
      <div class="carousel-caption text-left">
        <div class="container" data-aos="zoom-out" data-aos-delay="100">
          <h1 class="slider-containt">The Soul Food and Bistro</h1>
          <p>The Chef creates divine combinations</p>
          <div class="d-flex"> 
            <a href="#" class="cta">
                <span>Shop Now</span>
                <svg width="13px" height="10px" viewBox="0 0 13 10">
                  <path d="M1,5 L11,5"></path>
                  <polyline points="8 1 12 5 8 9"></polyline>
                </svg>
              </a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev"> <span class="carousel-control-prev-icon" aria-hidden="true"></span> <span class="sr-only">Previous</span> </a> <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next"> <span class="carousel-control-next-icon" aria-hidden="true"></span> <span class="sr-only">Next</span> </a> </div>
<!-- End Hero -->

<main id="main">
  <section class="elementor-element">
    <div class="container">
      <div class="row">
        <h2 class="elementor-heading-title mb-2">Welcome to our healthy farm!</h2>
        <p class="elementor-image-box-description text-center">Lorem Ipsum is simply dummy text of the printing and</p>
      </div>
      <div class="row">
        <div class="col-md-4">
          <div class="elementor-image-box-wrapper">
            <figure class="elementor-image-box-img"> <img src="assets/img/1.webp" class="attachment-full size-full" alt="" width="66" height="54"> </figure>
            <div class="elementor-image-box-content">
              <p class="elementor-image-box-title">Best Quality Products</p>
              <p class="elementor-image-box-description"> We stand for providing the most fresh organic products which will serve your health 
                and be a source of vitamins and minerals for our clients. </p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="elementor-image-box-wrapper">
            <figure class="elementor-image-box-img"> <img src="assets/img/2-1.webp" class="attachment-full size-full" alt="" width="66" height="54"> </figure>
            <div class="elementor-image-box-content">
              <p class="elementor-image-box-title">Farmer Products</p>
              <p class="elementor-image-box-description"> We work with many farms to provide you with natural products grown with love and care with no GMO or pesticides. </p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="elementor-image-box-wrapper">
            <figure class="elementor-image-box-img"> <img src="assets/img/3.webp" class="attachment-full size-full" alt="" width="66" height="54"> </figure>
            <div class="elementor-image-box-content">
              <p class="elementor-image-box-title">Fast Delivery</p>
              <p class="elementor-image-box-description"> We want our client to receive their fresh products as soon as possible, so we process and ship the order at once. </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section>
    <div class="container">
      <div class="row">
        <h2 class="elementor-heading-title mb-3">Top Categories</h2>
        <p class="elementor-image-box-description text-center">Lorem Ipsum is simply dummy text of the printing and</p>
      </div>
      <div class="row" data-aos="fade-up" data-aos-delay="100">
        <div class="col-lg-12 d-flex justify-content-center mt-3"> 
          <!-- Nav pills -->
          <ul class="nav nav-pills Categories-portfolio" role="tablist">
            <li class="nav-item"> <a class="nav-link active" data-toggle="pill" href="#Feel-Better">Feel-Better Food</a> </li>
            <li class="nav-item"> <a class="nav-link" data-toggle="pill" href="#Home-bistro">Home Bistro</a> </li>
            <li class="nav-item"> <a class="nav-link" data-toggle="pill" href="#One-Bowl">One-Bowl Nourishers</a> </li>
            <li class="nav-item"> <a class="nav-link" data-toggle="pill" href="#Takeout-twists">Takeout Twists</a> </li>
          </ul>
        </div>
        <div class="col-lg-12 d-flex justify-content-center mt-2"> 
          <!-- Tab panes -->
          <div class="tab-content w-100">
            <div id="Feel-Better" class="container tab-pane active filter-active"><br>
              <div class="row">
                <div class="col-lg-4 col-xl-3 col-md-6">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> 
                        <a href="" data-toggle="modal" data-target="#myModal"> 
                          <img src="assets/img/product-img/production-meal-image.jpg" class="img-fluid"> 
                        </a> 
                      </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Steak Peppercorn</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon">
                             <a href="#" class="tooltip" title="Protein Shake">  
                              <span class="tooltiptext">Protein Shake</span>
                              <img src="assets/img/protein-shake.svg" alt="<500 Cal"> 
                             </a>  
                            </div>
                            <div class="meal-icon" title=""> 
                             <a href="" class="tooltip">
                             <span class="tooltiptext">High Protein</span>
                              <img src="assets/img/hamburger.svg" alt="High Protein"> 
                              </a>
                            </div>
                            <div class="meal-icon"> <img src="assets/img/vegetables.svg" alt="Soy Free"> </div>
                            <div class="meal-icon" > <img src="assets/img/tool-menu.svg" alt="show more"> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                 <div class="col-lg-4 col-xl-3 col-md-6">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> <a href=""> <img src="assets/img/product-img/production-meal-image.webp" class="img-fluid"> </a> </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Super Pesto & Sausage Penne</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon" data-toggle="tooltip" data-placement="top" title="Hooray!"> 
                              <a href="" data-toggle="tooltip" title="Hooray!">
                              <img src="assets/img/protein-shake.svg" alt="<500 Cal"> 
                              </a>
                            </div>
                            <div class="meal-icon" title=""> <img src="assets/img/hamburger.svg" alt="High Protein"> </div>
                            <div class="meal-icon"> <img src="assets/img/vegetables.svg" alt="Soy Free"> </div>
                            <div class="meal-icon" > <img src="assets/img/tool-menu.svg" alt="show more"> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4 col-xl-3 col-md-6 portfolio-item filter-bistro">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> 
                        <a href=""> <img src="assets/img/product-img/production-meal-image.jpg" class="img-fluid"> </a> 
                      </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Steak Peppercorn</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon" data-toggle="tooltip" data-placement="top" title="Hooray!"> <img src="assets/img/protein-shake.svg" alt="<500 Cal"> </div>
                            <div class="meal-icon" title=""> <img src="assets/img/hamburger.svg" alt="High Protein"> </div>
                            <div class="meal-icon"> <img src="assets/img/vegetables.svg" alt="Soy Free"> </div>
                            <div class="meal-icon" > <img src="assets/img/tool-menu.svg" alt="show more"> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                 <div class="col-lg-4 col-xl-3 col-md-6">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> <a href=""> <img src="assets/img/product-img/production-meal-image.webp" class="img-fluid"> </a> </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Super Pesto & Sausage Penne</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon" data-toggle="tooltip" data-placement="top" title="Hooray!"> <img src="assets/img/protein-shake.svg" alt="<500 Cal"> </div>
                            <div class="meal-icon" title=""> <img src="assets/img/hamburger.svg" alt="High Protein"> </div>
                            <div class="meal-icon"> <img src="assets/img/vegetables.svg" alt="Soy Free"> </div>
                            <div class="meal-icon" > <img src="assets/img/tool-menu.svg" alt="show more"> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div id="Home-bistro" class="container tab-pane fade"><br>
              <div class="row" data-aos="fade-up" data-aos-delay="200">
                <div class="col-lg-4 col-xl-3 col-md-6">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> <a href=""> <img src="assets/img/product-img/production-meal-image.webp" class="img-fluid"> </a> </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Super Pesto & Sausage Penne</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon" data-toggle="tooltip" data-placement="top" title="Hooray!"> <img src="assets/img/protein-shake.svg" alt="<500 Cal"> </div>
                            <div class="meal-icon" title=""> <img src="assets/img/hamburger.svg" alt="High Protein"> </div>
                            <div class="meal-icon"> <img src="assets/img/vegetables.svg" alt="Soy Free"> </div>
                            <div class="meal-icon" > <img src="assets/img/tool-menu.svg" alt="show more"> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4 col-xl-3 col-md-6  portfolio-item filter-app">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> <a href=""> <img src="assets/img/product-img/production-meal-image-4.webp" class="img-fluid"> </a> </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Steak Peppercorn</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon" data-toggle="tooltip" data-placement="top" title="Hooray!"> <img src="assets/img/protein-shake.svg" alt="<500 Cal"> </div>
                            <div class="meal-icon" title=""> <img src="assets/img/hamburger.svg" alt="High Protein"> </div>
                            <div class="meal-icon"> <img src="assets/img/vegetables.svg" alt="Soy Free"> </div>
                            <div class="meal-icon" > <img src="assets/img/tool-menu.svg" alt="show more"> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div id="One-Bowl" class="container tab-pane fade"><br>
              <div class="row" data-aos="fade-up" data-aos-delay="200">
                <div class="col-lg-4 col-xl-3 col-md-6">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> <a href=""> <img src="assets/img/product-img/production-meal-image.webp" class="img-fluid"> </a> </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Super Pesto & Sausage Penne</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon" data-toggle="tooltip" data-placement="top" title="Hooray!"> <img src="assets/img/protein-shake.svg" alt="<500 Cal"> </div>
                            <div class="meal-icon" title=""> <img src="assets/img/hamburger.svg" alt="High Protein"> </div>
                            <div class="meal-icon"> <img src="assets/img/vegetables.svg" alt="Soy Free"> </div>
                            <div class="meal-icon" > <img src="assets/img/tool-menu.svg" alt="show more"> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4 col-xl-3 col-md-6  portfolio-item filter-app">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> <a href=""> <img src="assets/img/product-img/production-meal-image-4.webp" class="img-fluid"> </a> </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Steak Peppercorn</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon" data-toggle="tooltip" data-placement="top" title="Hooray!"> <img src="assets/img/protein-shake.svg" alt="<500 Cal"> </div>
                            <div class="meal-icon" title=""> <img src="assets/img/hamburger.svg" alt="High Protein"> </div>
                            <div class="meal-icon"> <img src="assets/img/vegetables.svg" alt="Soy Free"> </div>
                            <div class="meal-icon" > <img src="assets/img/tool-menu.svg" alt="show more"> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div id="Takeout-twists" class="container tab-pane fade"><br>
              <div class="row" data-aos="fade-up" data-aos-delay="200">
                <div class="col-lg-4 col-xl-3 col-md-6">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> <a href=""> <img src="assets/img/product-img/production-meal-image.webp" class="img-fluid"> </a> </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Super Pesto & Sausage Penne</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon" data-toggle="tooltip" data-placement="top" title="Hooray!"> <img src="assets/img/protein-shake.svg" alt="<500 Cal"> </div>
                            <div class="meal-icon" title=""> <img src="assets/img/hamburger.svg" alt="High Protein"> </div>
                            <div class="meal-icon"> <img src="assets/img/vegetables.svg" alt="Soy Free"> </div>
                            <div class="meal-icon" > <img src="assets/img/tool-menu.svg" alt="show more"> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4 col-xl-3 col-md-6  portfolio-item filter-app">
                  <div class="meal-card-wrapper">
                    <div class="meal-card">
                      <div class="meal-img"> <a href=""> <img src="assets/img/product-img/production-meal-image-4.webp" class="img-fluid"> </a> </div>
                      <div>
                        <div class="nutridock-meal mt-2">
                          <div class="nutridock-meal-name text-center"> <span title="Steak Peppercorn">Steak Peppercorn</span> </div>
                          <div class="nutridock-meal-ingredients text-center"> <span class="txt-side-dish-s" title="with Sautéed Carrots &amp; French Green Beans">with Sautéed Carrots &amp; French Green Beans</span> </div>
                          <div class="nutridock-icon over-xs-limit">
                            <div class="meal-icon" data-toggle="tooltip" data-placement="top" title="Hooray!"> <img src="assets/img/protein-shake.svg" alt="<500 Cal"> </div>
                            <div class="meal-icon" title=""> <img src="assets/img/hamburger.svg" alt="High Protein"> </div>
                            <div class="meal-icon"> <img src="assets/img/vegetables.svg" alt="Soy Free"> </div>
                            <div class="meal-icon" > <img src="assets/img/tool-menu.svg" alt="show more"> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="buyer-section">
    <div class="container">
      <div class="row">
        <h2 class="elementor-heading-title mb-3">Why Us</h2>
        <p class="elementor-image-box-description text-center col-lg-6 mx-auto"> Weekly recipe rotations for all skill levels and dietary preferences means there's always something new and exciting to cook. </p>
      </div>
      <div class="row mt-3">
        <div class="col-md-6">
          <div class="buyer-img"> <img src="assets/img/buyer-1.svg" class="img-fluid"> </div>
        </div>
        <div class="col-md-6 align-self-center">
          <div class="buyer-containt">
            <div class="text-center text-sm-left">
              <h3>Make It Yours</h3>
              <p>Make meals uniquely yours. Upgrade, double-up, add or swap protein on select meals. You’re in control of your dinstiny.* </p>
              <p>*dinstiny (n): a combination of dinner and destiny</p>
              <!-- <button class="btn btn-success build-your">Build Your Box</button> -->
            </div>
          </div>
        </div>
      </div>
      <div class="row mt-4">
        <div class="col-md-6 offset-md-1 align-self-center">
          <div class="buyer-containt">
            <div class="text-center text-sm-left">
              <h3>Make It Yours</h3>
              <p>Make meals uniquely yours. Upgrade, double-up, add or swap protein on select meals. You’re in control of your dinstiny.* </p>
              <p>*dinstiny (n): a combination of dinner and destiny</p>
              <!-- <button class="btn btn-success build-your">Build Your Box</button> -->
            </div>
          </div>
        </div>
        <div class="col-md-5">
          <div class="buyer-img"> <img src="assets/img/buyer-2.png" class="img-fluid"> </div>
        </div>
      </div>
    </div>
  </section>
  
  <!-- ======= Testimonials Section ======= -->
  <section id="testimonials" class="testimonials">
    <div class="container">
      <div class="row">
        <h2 class="elementor-heading-title mb-4 mt-3 text-white">Our Clients Testimonials</h2>
      </div>
    </div>
    <div class="container" data-aos="zoom-in">
      <div class="owl-carousel testimonials-carousel">
        <div class="testimonial-item"> <img src="assets/img/testimonials/testimonials-1.jpg" class="testimonial-img" alt=""> <img src="assets/img/quote.svg" class="d-block mx-auto m-2" style="max-width: 40px">
          <p> Proin iaculis purus consequat sem cure digni ssim donec porttitora entum suscipit rhoncus. Accusantium quam, ultricies eget id, aliquam eget nibh et. Maecen aliquam, risus at semper. </p>
          <h3 class="text-dark">Saul Goodman</h3>
          <h4>Ceo &amp; Founder</h4>
        </div>
        <div class="testimonial-item"> <img src="assets/img/testimonials/testimonials-2.jpg" class="testimonial-img" alt=""> <img src="assets/img/quote.svg" class="d-block mx-auto m-2" style="max-width: 40px">
          <p> Export tempor illum tamen malis malis eram quae irure esse labore quem cillum quid cillum eram malis quorum velit fore eram velit sunt aliqua noster fugiat irure amet legam anim culpa. </p>
          <h3 class="text-dark">Sara Wilsson</h3>
          <h4>Designer</h4>
        </div>
        <div class="testimonial-item"> <img src="assets/img/testimonials/testimonials-3.jpg" class="testimonial-img" alt=""> <img src="assets/img/quote.svg" class="d-block mx-auto" style="max-width: 50px">
          <p> Enim nisi quem export duis labore cillum quae magna enim sint quorum nulla quem veniam duis minim tempor labore quem eram duis noster aute amet eram fore quis sint minim. </p>
          <h3>Jena Karlis</h3>
          <h4>Store Owner</h4>
        </div>
        <div class="testimonial-item"> <img src="assets/img/testimonials/testimonials-4.jpg" class="testimonial-img" alt=""> <img src="assets/img/quote.svg" class="d-block mx-auto m-2" style="max-width: 40px">
          <p> Fugiat enim eram quae cillum dolore dolor amet nulla culpa multos export minim fugiat minim velit minim dolor enim duis veniam ipsum anim magna sunt elit fore quem dolore labore illum veniam. </p>
          <h3>Matt Brandon</h3>
          <h4>Freelancer</h4>
        </div>
      </div>
    </div>
  </section>

  
<section class="newsletter-section orange-bg">
  <div class="container mt-3">
    <div class="row">
      <div class="col-lg-4 col-md-4">
        <div class="newsletter-image">
          <img class="img-responsive center-block" src="assets/img/15.png" alt="">
        </div>
      </div>
      <div class="col-lg-8 col-md-8 text-center">
        <div class="newsletter-title mb-4 text-md-left">
          <h4 class="text-dark">Subscribe to get the free guide to easy and enjoyable nutrition! </h4>
        </div>
        <form class="form-inline">
          <div class="row">
            <div class="col-lg-8 col-md-8 col-sm-7 mb-2">
              <div class="form-group">
                <input type="text" class="form-control" id="inputPassword2" placeholder="Enter your email address...">
              </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-5 text-left">
              <a class="button black" href="#">Subscribe now</a>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>
  <!-- End Testimonials Section --> 
</main>
<!-- End #main --> 
  <!-- The Modal -->
  <div class="modal" id="myModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h3 class="modal-title">Steak Peppercorn </h3>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body" style="background-color: #f7f7f7;">
          <div>
            <ul class="list-inline mb-0" data-test="tags">
              <li class="list-inline-item mr-1 mb-1"><span class="badge-list-item">&lt;500 Cal</span></li>
              <li class="list-inline-item mr-1 mb-1"><span class="badge-list-item">Gluten Free</span></li>
              <li class="list-inline-item mr-1 mb-1"><span class="badge-list-item">&lt;35g Carbs</span></li>
              <li class="list-inline-item mr-1 mb-1"><span class="badge-list-item">High Protein</span></li>
              <li class="list-inline-item mr-1 mb-1"><span class="badge-list-item">Soy Free</span></li>
            </ul>
          </div>
          <div class="MealModal-module">
            <article class="meals-overlay">
             <div>
               <div class="row">
                 <div class="col-md-5">
                   <div class="position-relative">
                     <img class="mb-3 w-100" src="https://res.cloudinary.com/freshly/image/upload/c_fill,dpr_2,f_auto,w_580/v1589575861/production-meal-image-09d83596-0409-4e39-9b3b-9b512c12c6e1.jpg">
                   </div>
                   <div class="position-relative">
                     <img class="mb-3 w-100" src="https://res.cloudinary.com/freshly/image/upload/c_fill,dpr_2,f_auto,w_580/v1574619598/production-meal-image-7424ee00-d9d6-4038-b190-a5d22da8ac56.jpg">
                   </div>
                   <div class="position-relative">
                     <img class="mb-3 w-100" src="https://res.cloudinary.com/freshly/image/upload/c_fill,dpr_2,f_auto,w_580/v1574619627/production-meal-image-17aa62ca-008b-4680-a2d7-4b274820065b.jpg">
                   </div>
                   <div class="position-relative">
                     <img class="mb-3 w-100" src="https://res.cloudinary.com/freshly/image/upload/c_fill,dpr_2,f_auto,w_580/v1574619652/production-meal-image-d09b8cb8-70ef-4b0d-8995-59420fc8c9da.jpg">
                   </div>
                   <div class="position-relative">
                     <img class="mb-3 w-100" src="https://res.cloudinary.com/freshly/image/upload/c_fill,dpr_2,f_auto,w_580/v1589575861/production-meal-image-09d83596-0409-4e39-9b3b-9b512c12c6e1.jpg">
                   </div>
                 </div>

                 <div class="col-md-7">
                  <section class="title-wrap">
                   <div class="heading-title-">
                     <h2 class="pl-3">What makes this dish special</h2>
                     <ul class="list-unstyled ml-n3 mb-0">
                       <li class="MealDetails-List pl-3 mb-4">
                         Juicy, oven-roasted chicken breast marinated in fragrant Italian herbs
                       </li>
                       <li class="MealDetails-List pl-3 mb-4">
                         Juicy, oven-roasted chicken breast marinated in fragrant Italian herbs
                       </li>
                       <li class="MealDetails-List pl-3 mb-4">
                         Juicy, oven-roasted chicken breast marinated in fragrant Italian herbs
                       </li>
                       <li class="MealDetails-List pl-3 mb-4">
                         Juicy, oven-roasted chicken breast marinated in fragrant Italian herbs
                       </li>
                     </ul>
                   </div>
                  </section> 

                  <section class="title-wrap">
                     <div class="heading-title-">
                       <h2 class="pl-3">Ingredients</h2>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <figure class="text-center">
                          <img class="Ingredients-img" alt="Chicken Breast" src="https://res.cloudinary.com/freshly/image/upload/c_fit,f_auto,h_300,w_300/v1557431212/production-image-3b1cc8ff-85dd-4dbd-be6d-f06a6e2ce0b3.png">
                          <figcaption class="Ingredients-title">Chicken Breast</figcaption>
                        </figure>
                      </div>
                      <div class="col-md-4">
                        <figure class="text-center">
                          <img class="Ingredients-img" alt="Chicken Breast" src="https://res.cloudinary.com/freshly/image/upload/c_fit,f_auto,h_300,w_300/v1544802880/production-image-11b08e84-b9f0-4a04-846c-4ac08fe0311b.png">
                          <figcaption class="Ingredients-title">Chicken Breast</figcaption>
                        </figure>
                      </div>
                      <div class="col-md-4">
                        <figure class="text-center">
                          <img class="Ingredients-img" alt="Chicken Breast" src="https://res.cloudinary.com/freshly/image/upload/c_fit,f_auto,h_300,w_300/v1545160945/production-image-8b009f04-d094-4396-9dc6-5f45fcd5c3fc.png">
                          <figcaption class="Ingredients-title">Chicken Breast</figcaption>
                        </figure>
                      </div>
                    </div>
                    <button class="show-all-ingredients" aria-expanded="false" aria-controls="ingredientsCollapsible">
                      Show all ingredients
                    </button>
                  </section>

                   <section class="title-wrap">
                    <div class="px-3">
                     <div class="heading-title-">
                       <h2 class="pl-0">What’s inside</h2>
                    </div>
                    <div class="row mb-4">
                      <div class="col-md-6">
                        <div class="Featured-Nutridock-module">
                          <span class="Calories-name">Calories</span>
                          <strong class="d-block">440</strong>
                          <div class="progress" style="height: 0.3rem;">
                            <div class="progress-bar bg-primary" style="width:40%"></div>
                          </div>
                          <small>25DV</small>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="Featured-Nutridock-module border-0">
                          <span class="Calories-name">Carbs</span>
                          <strong class="d-block">440</strong>
                          <div class="progress" style="height: 0.3rem;">
                            <div class="progress-bar bg-success" style="width:60%"></div>
                          </div>
                          <small>25DV</small>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="Featured-Nutridock-module pt-4" style="border-top: 1px solid #e1e1e1;">
                          <span class="Calories-name">Total Fat</span>
                          <strong class="d-block">170Kg</strong>
                          <div class="progress" style="height: 0.3rem;">
                            <div class="progress-bar bg-success" style="width:60%"></div>
                          </div>
                          <small>25DV</small>
                        </div>
                      </div>
                    </div>
                    <button class="show-all-ingredients" aria-expanded="false" aria-controls="ingredientsCollapsible">
                      Show all ingredients
                    </button>
                  </div>
                </section>
               </div>
             </div> 
            </article>
          </div>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>

      </div>
    </div>
  </div>
<?php include('footer.php')?>